# user-registration-php-mysql-ajax

Follow this tutorial: https://www.youtube.com/watch?v=cXWCVvfe4ao&list=PLCakfctNSHkFXKLQKX4jv7OEyWUcTgbfE
